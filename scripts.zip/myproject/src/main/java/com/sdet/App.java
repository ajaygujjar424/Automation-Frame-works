package com.sdet;

import java.util.ResourceBundle;

public class App {
	
	public int userLogin(String in_user, String in_pwd)
	{
		ResourceBundle rb=ResourceBundle.getBundle("config");// get from resource ....config file
		String userName=rb.getString("username");//geting from congif file
		String password=rb.getString("password");// geting from congif file
		
		
		if (in_user.equals(userName) && in_pwd.equals(password))
			return 1;
		else
			return 0;	
		
	}

}
////developer code next we have to write the test cases in srsc test.java